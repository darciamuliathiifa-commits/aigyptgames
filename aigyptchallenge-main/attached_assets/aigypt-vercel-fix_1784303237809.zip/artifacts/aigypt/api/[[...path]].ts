// Vercel Serverless Function — catch-all handler for /api/* routes.
// Imports the pre-bundled Express app (CJS bundle built by `pnpm build:fn`).
// Runtime: @vercel/node (Node.js, not Edge).
//
// The bundle at ./_bundled/app.cjs is produced by artifacts/api-server/build-fn.mjs
// and committed to the repo so Vercel always has it without needing a monorepo build.

// @ts-ignore — CJS bundle, no type declarations needed
import mod from "./_bundled/app.cjs";

// esbuild's CJS output wraps the app as `module.exports = { default: app }`.
// When this ESM file default-imports that CJS module, Node interop hands us
// the whole exports OBJECT, not the Express function — and Vercel then tries
// to invoke an object as a handler → FUNCTION_INVOCATION_FAILED.
// Unwrap `.default` (recursively, to be safe) so the export is always the
// actual Express request handler function.
function unwrap(m: any): any {
  let cur = m;
  for (let i = 0; i < 3 && cur && typeof cur !== "function" && cur.default; i++) {
    cur = cur.default;
  }
  return cur;
}

const app = unwrap(mod);

if (typeof app !== "function") {
  throw new Error(
    "aigypt api: bundled Express app did not resolve to a function — check api/_bundled/app.cjs",
  );
}

export default app;
